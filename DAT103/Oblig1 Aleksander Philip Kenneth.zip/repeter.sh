#!/bin/bash

for ((i=0; i<$1; i++))
do
    echo $2
done
